# Identify which columns in the movie table have null values

import pandas as pd

df = pd.read_excel('../imdb.xlsx', sheet_name='movies')
print(df.isnull().any())
