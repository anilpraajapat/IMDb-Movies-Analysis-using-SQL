# Find the total number of rows in each table of the schema

import sqlite3
import pandas as pd

con = sqlite3.connect('../imdb.db')
excel = pd.read_excel('../imdb.xlsx',sheet_name = None)

for sheet in excel:
	if sheet=='ERD':
		continue
	df=pd.read_sql_query('SELECT count(*) as total FROM {0}'.format(sheet), con)
	print('Table :',sheet,' have ',df['total'][0],' Rows')