# Identify the genre with the highest number of movies produced overall

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
df= pd.read_sql_query("SELECT count(id) as total, genre FROM genre INNER JOIN movies ON movie_id=id GROUP BY genre order by total desc limit 1", con);
print(df['genre'][0],'-',df['total'][0])
