# Retrieve details for the top nine directors based on the number of movies, including average inter-movie duration, ratings, and more.


import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query('''
WITH directors AS (
    SELECT
        names.name,
        COUNT(movies.id) AS movie_count,
        AVG(duration) AS avg_duration,
        avg(avg_rating) as avg_rating
	FROM movies
	INNER JOIN names ON names.id=director_mapping.name_id
	INNER JOIN ratings ON ratings.movie_id=movies.id
	INNER JOIN director_mapping ON director_mapping.movie_id=movies.id
    GROUP BY names.name
    ORDER BY movie_count DESC
    LIMIT 9
)
SELECT name, movie_count, avg_duration, avg_rating FROM directors;
''',con)
print(result)