# Identify the five highest-grossing movies of each year that belong to the top three genres

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query('''
WITH ranked_movies AS (
    SELECT
        movie_id,
        title,
        year,
        genre,
        ROW_NUMBER() OVER (PARTITION BY date_published, genre ORDER BY worlwide_gross_income DESC) AS rank
    FROM movies
	INNER JOIN genre ON genre.movie_id=movies.id
)

SELECT movie_id,title,year,genre FROM ranked_movies where rank <=5
''', con);
print(result)
