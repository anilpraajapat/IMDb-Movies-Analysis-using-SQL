# Identify the top three actresses based on the number of Super Hit movies (average rating > 8) in the drama genre.

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query('''
WITH actress_hits AS (
    SELECT
        names.name,
        COUNT(movies.id) AS super_hit_count
	FROM movies
	INNER JOIN genre ON genre.movie_id=movies.id
	INNER JOIN ratings ON ratings.movie_id=movies.id
	INNER JOIN names ON names.id=director_mapping.name_id
	INNER JOIN director_mapping ON director_mapping.movie_id=movies.id
    WHERE genre.genre = 'Drama' AND ratings.avg_rating > 8
    GROUP BY names.name
    ORDER BY super_hit_count DESC
)
SELECT name FROM actress_hits LIMIT 3;
''', con);
print(result)
