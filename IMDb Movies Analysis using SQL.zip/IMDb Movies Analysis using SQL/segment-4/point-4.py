# Identify the production house that has produced the most number of hit movies (average rating > 8).

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query('''
SELECT
	production_company,avg_rating
FROM movies
LEFT JOIN ratings ON movie_id=id
WHERE avg_rating>8
GROUP BY production_company
''', con);
print(result)