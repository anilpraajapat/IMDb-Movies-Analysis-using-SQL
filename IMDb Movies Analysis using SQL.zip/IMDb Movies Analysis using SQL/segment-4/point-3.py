# Summarise the ratings table based on movie counts by median ratings

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query('''
SELECT
	median_rating,
    COUNT(*) AS movie_count
FROM
    ratings
GROUP BY
    median_rating;
''', con);
print(result)