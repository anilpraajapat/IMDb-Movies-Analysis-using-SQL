# Retrieve movies of each genre starting with the word 'The' and having an average rating > 8.

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query('''
SELECT
	movies.title, genre, avg_rating
FROM movies
INNER JOIN genre ON id=genre.movie_id
INNER JOIN ratings ON id=ratings.movie_id
WHERE title LIKE 'The%' AND avg_rating>8
GROUP BY genre, id;
''', con);
print(result)