# Determine the number of movies released in each genre during March 2017 in the USA with more than 1,000 votes.

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query('''
SELECT
    genre,
    COUNT(*) AS movies_count
FROM movies
INNER JOIN genre ON id=genre.movie_id
INNER JOIN ratings ON id=ratings.movie_id
WHERE
	strftime('%Y-%m', date_published) = '2017-03'
    AND country = 'USA'
    AND total_votes > 1000
GROUP BY genre;
''', con);
print(result)