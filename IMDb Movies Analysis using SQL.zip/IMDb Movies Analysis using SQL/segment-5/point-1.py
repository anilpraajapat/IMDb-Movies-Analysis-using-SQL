# Identify the columns in the names table that have null values

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query('''
SELECT COUNT(*) FROM names WHERE name || height || known_for_movies || date_of_birth IS NULL;
''', con);
print(result)