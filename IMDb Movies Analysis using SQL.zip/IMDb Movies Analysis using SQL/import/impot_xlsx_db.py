import sqlite3
import pandas as pd

con = sqlite3.connect('imdb.db')
excel = pd.read_excel('imdb.xlsx',sheet_name = None)

for sheet in excel:
	if sheet=='ERD':
		continue
	excel[sheet].to_sql(sheet,con,index=False)
con.commit()
con.close()